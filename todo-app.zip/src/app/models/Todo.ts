export class Todo {
  content: string = 'todo description';
  completed: boolean = false;
}
